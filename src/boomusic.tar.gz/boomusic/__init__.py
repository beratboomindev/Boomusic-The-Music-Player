"""Boomusic - The Music Player.

Basit, tepsi (tray) simgesi üzerinden çalışan yerel müzik çalar.
YouTube Music entegrasyonu dahildir.
"""

__version__ = "1.7.gd"
__app_name__ = "Boomusic - The Music Player"
